//#include <iostream>
//#include <chrono>
//#include <thread>
//using namespace std;
//
//int main()
//{
//    cout << "Hello waiter" << endl;
//    chrono::seconds dura(5);
//    this_thread::sleep_for(dura);
//    cout << "Waited 5s\n";
//    return 0;
//}